import requests
import json
import re

class TranslatorEngine:
    def __init__(self, source="ja", target="zh-CN", use_ollama=True, model="gemma"):
        """
        Translator using Ollama local LLM or Google Translate fallback.
        :param use_ollama: If True, use local Ollama. If False, use Google Translate.
        :param model: Ollama model name (e.g., 'gemma', 'gemma2', 'llama3')
        """
        self.use_ollama = use_ollama
        self.model = model
        self.ollama_url = "http://localhost:11434/api/generate"
        
        # Fallback to Google
        if not use_ollama:
            from deep_translator import GoogleTranslator
            self.google = GoogleTranslator(source=source, target=target)
        
        # System prompt for translation
        self.prompt_template = """请将以下日语翻译成中文，只输出翻译结果，不要添加任何解释：

日语：{text}

中文翻译："""

    def translate(self, text):
        if not text or not text.strip():
            return ""
        
        if self.use_ollama:
            return self._translate_ollama(text)
        else:
            return self._translate_google(text)
    
    def _translate_ollama(self, text):
        """Translate using local Ollama."""
        try:
            # Use IP to avoid Windows localhost 2s delay
            url = "http://127.0.0.1:11434/api/generate" 
            
            # Simplified Prompt for 1.8b model: Direct Instruction.
            # Few-shot was causing it to copy the input. Force it with a clear command.
            prompt = f"Translate the following Japanese text to Simplified Chinese directly. Output ONLY the translation.\n\n{text}"
            
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,
                    "num_ctx": 1024,
                    # Remove "Japanese:" from stop tokens as we changed format
                    "stop": ["\n"] 
                }
            }
            
            response = requests.post(
                url,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                translation = result.get("response", "").strip()
                
                # --- Post-processing / Cleaning ---
                # Take first line only (often models output explanation after newline)
                translation = translation.split("\n")[0].strip()
                
                # Remove common prefixes that small models hallucinate
                prefixes_to_clean = ["日语：", "中文：", "翻译：", "中文翻译：", "日语:", "中文:", "翻译:", "中文翻译:"]
                for prefix in prefixes_to_clean:
                    if translation.startswith(prefix):
                        translation = translation[len(prefix):].strip()
                
                # Special case: sometimes it repeats the source text in parens
                # e.g. "你好 (Konnichiwa)" -> remove parens if needed, but risky.
                
                return translation if translation else text
            else:
                print(f"Ollama error: {response.status_code}")
                return text
                
        except requests.exceptions.ConnectionError:
            print("Ollama not running, falling back to Google")
            self.use_ollama = False
            from deep_translator import GoogleTranslator
            self.google = GoogleTranslator(source="ja", target="zh-CN")
            return self._translate_google(text)
        except Exception as e:
            print(f"Ollama translation error: {e}")
            return text
    
    def _translate_google(self, text):
        """Fallback to Google Translate."""
        try:
            return self.google.translate(text)
        except Exception as e:
            print(f"Google translation error: {e}")
            return text
